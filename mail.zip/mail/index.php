<!DOCTYPE html>
<html>
<head>
	<title>FSociety Mail Spoofer</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			background-color: #222;
			color: #fff;
			margin: 0;
			padding: 0;
		}
		h1 {
			font-size: 2.5em;
			margin-top: 20px;
			margin-bottom: 20px;
			text-align: center;
		}
		form {
			margin: 0 auto;
			max-width: 600px;
			background-color: #333;
			padding: 20px;
			border-radius: 10px;
			box-shadow: 0px 0px 10px #000;
		}
		label {
			display: block;
			font-size: 1.2em;
			margin-bottom: 5px;
		}
		input[type="email"], input[type="text"], textarea {
			width: 100%;
			padding: 10px;
			margin-bottom: 20px;
			border-radius: 5px;
			border: none;
			background-color: #444;
			color: #fff;
			font-size: 1.2em;
			resize: none;
		}
		input[type="submit"] {
			display: block;
			margin: 0 auto;
			padding: 10px 20px;
			background-color: #444;
			color: #fff;
			font-size: 1.2em;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			transition: background-color 0.2s ease;
		}
		input[type="submit"]:hover {
			background-color: #555;
		}
	</style>
</head>
<body>
	<h1>FSociety Mail Spoofer</h1>
	<form action="mail.php" method="post">
		<label for="recipient_email">Recipient Email:</label>
		<input type="email" name="recipient_email" required>

		<label for="subject">Subject:</label>
		<input type="text" name="subject" required>

		<label for="message">Message:</label>
		<textarea name="message" rows="5" cols="30" required></textarea>

		<label for="from_email">From Email:</label>
		<input type="email" name="from_email" placeholder="Leave blank to use default">

		<input type="submit" value="Send Email">
	</form>
</body>
</html>
