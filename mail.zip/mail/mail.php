<?php
// Retrieve the form data
$to = $_POST['recipient_email'];
$subject = $_POST['subject'];
$message = $_POST['message'];
$from = isset($_POST['from_email']) ? $_POST['from_email'] : 'yourname@yourdomain.com';

// Set the email headers
$headers = 'From: ' . $from . "\r\n" .
    'Reply-To: ' . $from . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

// Send the email
if (mail($to, $subject, $message, $headers)) {
    echo "Email sent successfully.";
} else {
    echo "Error: Email sending failed.";
}
?>
