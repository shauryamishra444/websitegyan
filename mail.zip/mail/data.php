<?php
$to_email = 'jarvisofyourbro@gmail.com';
$from_email = 'no-reply@data.com';
$subject = 'New data received';
$message = '';

// Loop through all the parameters passed in the URL
foreach ($_GET as $key => $value) {
    // Append the parameter name and value to the email message
    $message .= $key . ': ' . $value . "\n";
}

// Set headers for the email
$headers = 'From: ' . $from_email . "\r\n" .
    'Reply-To: ' . $from_email . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

// Send the email
mail($to_email, $subject, $message, $headers);

// Return a response to the client
echo "Data sent";
?>
